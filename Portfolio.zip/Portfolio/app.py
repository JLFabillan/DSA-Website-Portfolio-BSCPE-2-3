from flask import Flask, render_template, send_from_directory, abort
from routes.works import works_bp
from routes.touppercase import touppercase_bp
from routes.areaofcircle import areaofcircle_bp
from routes.areaoftriangle import areaoftriangle_bp
from routes.infixtopostfix import infixtopostfix_bp
import json

app = Flask(__name__)

# Register blueprints
app.register_blueprint(touppercase_bp)
app.register_blueprint(areaofcircle_bp)
app.register_blueprint(areaoftriangle_bp)
app.register_blueprint(works_bp)
app.register_blueprint(infixtopostfix_bp)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route("/library")
def library():
    with open("static/data/library.json") as f:
        files = json.load(f)
    return render_template("library.html", files=files)

@app.route("/download/<path:filename>")
def download_file(filename):
    try:
        return send_from_directory( 
            directory="static/Labs",
            path=filename,
            as_attachment=True
        )
    except FileNotFoundError:
        abort(404)


if __name__ == "__main__":
    app.run(debug=True)
