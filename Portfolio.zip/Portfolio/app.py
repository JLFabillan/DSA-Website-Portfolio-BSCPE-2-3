from flask import Flask, render_template
from routes.works import works_bp
from routes.touppercase import touppercase_bp
from routes.areaofcircle import areaofcircle_bp
from routes.areaoftriangle import areaoftriangle_bp

app = Flask(__name__)

# Register blueprints
app.register_blueprint(touppercase_bp)
app.register_blueprint(areaofcircle_bp)
app.register_blueprint(areaoftriangle_bp)
app.register_blueprint(works_bp)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == "__main__":
    app.run(debug=True)
