from flask import Blueprint, render_template, request

works_bp = Blueprint('works', __name__, url_prefix='/works')

@works_bp.route('/')
def index():
    return render_template('works/index.html')
