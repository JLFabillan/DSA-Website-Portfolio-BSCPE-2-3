from flask import Blueprint, render_template, request

areaoftriangle_bp = Blueprint('areaoftriangle', __name__)

@areaoftriangle_bp.route('/areaoftriangle', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        try:
            base = float(request.form.get('base', 0))
            height = float(request.form.get('height', 0))
            result = (base * height) / 2
        except:
            result = "Invalid input!"
    return render_template('works/areaoftriangle.html', result=result)
