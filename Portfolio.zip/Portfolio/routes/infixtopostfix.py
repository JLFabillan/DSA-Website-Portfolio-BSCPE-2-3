from flask import Blueprint, render_template, request

infixtopostfix_bp = Blueprint('infixtopostfix', __name__)

# Shunting Yard Algorithm
def infix_to_postfix(expression):
    precedence = {
        '^': 3,
        '*': 2,
        '/': 2,
        '+': 1,
        '-': 1
    }

    stack = []
    output = []
    expression = expression.replace(" ", "")

    # Allowed characters check
    for char in expression:
        if not (char.isalnum() or char in "+-*/^()"):
            return "Invalid character detected: " + char

    for char in expression:
        if char.isalnum():
            output.append(char)
        elif char == '(':
            stack.append(char)
        elif char == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            if not stack:
                return "Error: Mismatched parentheses."
            stack.pop()
        else:
            while stack and stack[-1] != '(' and precedence.get(stack[-1], 0) >= precedence.get(char, 0):
                output.append(stack.pop())
            stack.append(char)

    while stack:
        top = stack.pop()
        if top == '(':
            return "Error: Mismatched parentheses."
        output.append(top)

    return ' '.join(output)

@infixtopostfix_bp.route('/infixtopostfix', methods=['GET', 'POST'])
def index():
    result = None

    if request.method == 'POST':
        infix_expression = request.form.get('inputString', '').strip()

        if not infix_expression:
            result = "Input cannot be empty."
        else:
            result = infix_to_postfix(infix_expression)

    return render_template('works/infixtopostfix.html', result=result)
