from flask import Blueprint, render_template, request
import math

areaofcircle_bp = Blueprint('areaofcircle', __name__)

@areaofcircle_bp.route('/areaofcircle', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        try:
            radius = float(request.form.get('radius', 0))
            result = math.pi * radius * radius
        except:
            result = "Invalid input!"
    return render_template('works/areaofcircle.html', result=result)
