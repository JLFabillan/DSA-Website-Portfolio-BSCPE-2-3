from flask import Blueprint, render_template, request

touppercase_bp = Blueprint('touppercase', __name__)

@touppercase_bp.route('/touppercase', methods=['GET', 'POST'])
def index():
    result = None

    if request.method == 'POST':
        text = request.form.get('inputString', '').strip()

        if text.isalpha():
            result = text.upper()
        else:
            result = "Input must contain letters only."

    return render_template('works/touppercase.html', result=result)
